/*
Group No: 26
Authors:
    Nithin Benny Myppan - 2016A7PS0014P
    Adhitya Mamallan    - 2016A7PS0028P
    Swarup N            - 2016A7PS0080P
    Naveen Unnikrishnan - 2016A7PS0111P
*/
#ifndef _LEXER_DEF_H
#define _LEXER_DEF_H

#include <stdlib.h>
#include <stdio.h>

typedef enum{           // Tokens (terminal symbols) in the grammar
    TK_ASSIGNOP,
    TK_COMMENT,
    TK_FIELDID,
    TK_ID,
    TK_NUM,
    TK_RNUM,
    TK_FUNID,
    TK_RECORDID,
    TK_WITH,
    TK_PARAMETERS,
    TK_END,
    TK_WHILE,
    TK_TYPE,
    TK_MAIN,
    TK_GLOBAL,
    TK_PARAMETER,
    TK_LIST,
    TK_SQL,
    TK_SQR,
    TK_INPUT,
    TK_OUTPUT,
    TK_INT,
    TK_REAL,
    TK_COMMA,
    TK_SEM,
    TK_COLON,
    TK_DOT,
    TK_ENDWHILE,
    TK_OP,
    TK_CL,
    TK_IF,
    TK_THEN,
    TK_ENDIF,
    TK_READ,
    TK_WRITE,
    TK_RETURN,
    TK_PLUS,
    TK_MINUS,
    TK_MUL,
    TK_DIV,
    TK_CALL,
    TK_RECORD,
    TK_ENDRECORD,
    TK_ELSE,
    TK_AND,
    TK_OR,
    TK_NOT,
    TK_LT,
    TK_LE,
    TK_EQ,
    TK_GT,
    TK_GE,
    TK_NE,
    TK_ERROR,
    EPS,                    // Empty string. Terminal symbol.
    DOLLAR                  // Bottom of stack
}Token_type;

typedef union{              // Union storing value stored in variable (either integer or real number)
    int integer;
    float real;
}Val;

typedef struct lexical_unit{    // Lexical unit (tokenInfo) returned by the lexer
    Token_type token; // Token
    int line_no;      // Line number
    char* lexeme;     // Lexeme
    Val *val;         // Value stored (only applicable for TK_NUM and TK_RNUM)
}Lexical_Unit;

#endif